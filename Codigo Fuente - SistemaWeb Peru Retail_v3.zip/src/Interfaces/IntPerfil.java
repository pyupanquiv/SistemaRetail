package Interfaces;

import java.util.List;

import Modelo.Perfil;

public interface IntPerfil {
	public List<Perfil> ListarPerfil();
}
