package ConexionBD;

public class TestConexionBD {
	public static void main(String[] args) {
		ConexionBD.conexion();
	}
}
