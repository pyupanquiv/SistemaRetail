package Interfaces;

public interface IntVenta {
	public String GenerarSerie();
}
